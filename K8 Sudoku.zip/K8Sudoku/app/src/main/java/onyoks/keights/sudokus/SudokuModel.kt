package onyoks.keights.sudokus

import androidx.annotation.Keep

@Keep
data class SudokuModel(
    val title: String
)
