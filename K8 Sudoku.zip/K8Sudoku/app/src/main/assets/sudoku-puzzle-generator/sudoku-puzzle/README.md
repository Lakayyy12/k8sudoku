# Sudoku puzzle generator

A Pen created on CodePen.io. Original URL: [https://codepen.io/cawoelk/pen/WxJPLj](https://codepen.io/cawoelk/pen/WxJPLj).

Very slow load...but the brute force method is all I've come up with to generate a unique and solvable board.
The difficulty level is pretty low too, as I haven't applied any special algorithms for figuring out which specific numbers would be needed and which could be blank for the puzzle to be solvable.
No puzzle-check yet either.